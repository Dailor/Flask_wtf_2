from flask import Flask, render_template


app = Flask(__name__)


@app.route('/<string:title>')
@app.route('/index/<string:title>')
def index(title):
    html = render_template('index.html', title=title)
    return html


@app.route('/training/<prof>')
def proff(prof):
    html = render_template('training.html', title=prof)
    return html


if __name__ == '__main__':
    app.run(port=8080, host='localhost')
